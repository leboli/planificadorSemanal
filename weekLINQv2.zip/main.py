from PlannerGUI import GUI
import flet as ft 

if __name__ == "__main__":
    ft.app(target=GUI)